let selectedTopic = 'tiktok';

function selectTopic(topic) {
  selectedTopic = topic;
  document.getElementById('promptArea').innerHTML = '';
}

function generatePrompt() {
  fetch(`prompts/${selectedTopic}.txt`)
    .then(res => res.text())
    .then(data => {
      const lines = data.trim().split('\n\n');
      const prompt = lines[Math.floor(Math.random() * lines.length)];
      document.getElementById('promptArea').innerHTML = `<pre>${prompt}</pre><button onclick="copyPrompt()">Copy 📋</button><div id='copiedMsg'></div>`;
    });
}

function copyPrompt() {
  const text = document.querySelector('#promptArea pre').innerText;
  navigator.clipboard.writeText(text).then(() => {
    document.getElementById('copiedMsg').innerText = '✅ Prompt copied!';
    setTimeout(() => document.getElementById('copiedMsg').innerText = '', 2000);
  });
}